# -*- coding: utf-8 -*-
import requests
import re
# Remarquez que nous n'importons pas `clean_title` directement ici pour éviter une importation circulaire

base_url = 'https://paste.lesalkodiques.com/raw/'

def source(paste_id):
    from modules.utils import clean_title  # Importation locale pour éviter l'importation circulaire

    url = f'{base_url}{paste_id}'
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"Failed to fetch data from {url}")

    raw_data = response.text.splitlines()
    if not raw_data or raw_data[0].split(';')[0].lower() != 'cat':
        raise Exception("Invalid data format")

    header = raw_data[0].split(';')
    data_entries = [line.split(';') for line in raw_data[1:]]

    results = []
    for entry in data_entries:
        if len(entry) != len(header):
            continue

        data_dict = dict(zip(header, entry))
        if 'CAT' not in data_dict or data_dict['CAT'].lower() != 'film':
            continue

        tmdb_id = data_dict.get('TMDB')
        title = data_dict.get('TITLE')
        year = data_dict.get('YEAR')
        genres = data_dict.get('GENRES')
        resolutions = data_dict.get('RES')
        urls = data_dict.get('URLS=https://alldebrid.com/f/').split(',')

        formatted_urls = [f"https://alldebrid.com/f/{url.strip()}" for url in urls]

        results.append({
            'scrape_provider': 'paste',
            'name': clean_title(title),
            'tmdb': tmdb_id,
            'title': title,
            'year': year,
            'genres': genres,
            'resolutions': resolutions,
            'urls': formatted_urls,
            'display_name': title,
            'source': 'paste',
            'size': 0,  # update with actual size if available
            'quality': 'HD',  # update with actual quality if available
            'extraInfo': '',
            'url': formatted_urls[0],  # assuming first URL is the main link
            'info': '',
            'direct': True,
            'debrid': '',
            'package': 'false',
            'type': 'movie'
        })
    
    return results

def resolve_paste(paste_id):
    # function to resolve the paste link
    return f"https://paste.lesalkodiques.com/raw/{paste_id}"

