Credit to **SimplePlugin 3** and **tmdbsimple** authors.

custom app api keys required as "default" in addon *resources/settings.xml* file.

tested only with Kodi Nexus on windows.